// middleware/auth.js
// Protects routes by verifying the JWT sent in the Authorization header

const jwt = require('jsonwebtoken');
const User = require('../models/User');

// ── protect ──────────────────────────────────────────────────
// Attach the logged-in user to req.user so route handlers can use it
const protect = async (req, res, next) => {
  let token;

  // Tokens arrive as:  Authorization: Bearer <token>
  if (req.headers.authorization && req.headers.authorization.startsWith('Bearer')) {
    token = req.headers.authorization.split(' ')[1];
  }

  if (!token) {
    return res.status(401).json({ message: 'Not authorised – no token provided' });
  }

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    // Fetch the user from DB (excluding the password field)
    req.user = await User.findById(decoded.id).select('-password');
    if (!req.user) {
      return res.status(401).json({ message: 'User no longer exists' });
    }
    next();
  } catch (error) {
    return res.status(401).json({ message: 'Not authorised – invalid token' });
  }
};

// ── adminOnly ─────────────────────────────────────────────────
// Must come AFTER protect in the middleware chain
const adminOnly = (req, res, next) => {
  if (req.user && req.user.role === 'admin') {
    return next();
  }
  res.status(403).json({ message: 'Access denied – admins only' });
};

module.exports = { protect, adminOnly };
