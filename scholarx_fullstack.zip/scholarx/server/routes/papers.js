// routes/papers.js  →  /api/papers
const express = require('express');
const router = express.Router();
const path = require('path');
const Paper = require('../models/Paper');
const { protect, adminOnly } = require('../middleware/auth');
const upload = require('../middleware/upload');

// ── GET /api/papers ──────────────────────────────────────────
// Fetch all papers with optional search (?q=) and field filter (?field=)
router.get('/', async (req, res) => {
  try {
    const { q, field, page = 1, limit = 20 } = req.query;
    const query = {};

    // Full-text search (uses the text index on title, abstract, authors)
    if (q) {
      query.$text = { $search: q };
    }

    // Filter by academic field
    if (field && field !== 'all') {
      query.field = field;
    }

    const skip = (Number(page) - 1) * Number(limit);

    const papers = await Paper.find(query)
      .populate('uploadedBy', 'name email') // Attach uploader info
      .sort({ createdAt: -1 })              // Newest first
      .skip(skip)
      .limit(Number(limit));

    const total = await Paper.countDocuments(query);

    res.json({
      papers,
      total,
      page: Number(page),
      pages: Math.ceil(total / Number(limit))
    });
  } catch (error) {
    console.error('Get papers error:', error.message);
    res.status(500).json({ message: 'Failed to fetch papers' });
  }
});

// ── GET /api/papers/:id ──────────────────────────────────────
// Fetch a single paper by its MongoDB ID
router.get('/:id', async (req, res) => {
  try {
    const paper = await Paper.findById(req.params.id)
      .populate('uploadedBy', 'name email');

    if (!paper) {
      return res.status(404).json({ message: 'Paper not found' });
    }

    res.json({ paper });
  } catch (error) {
    res.status(500).json({ message: 'Failed to fetch paper' });
  }
});

// ── POST /api/papers ─────────────────────────────────────────
// Upload a new paper (requires login)
// upload.single('pdf') handles the file; other fields come from req.body
router.post('/', protect, upload.single('pdf'), async (req, res) => {
  try {
    const { title, abstract, authors, field, year, fileUrl } = req.body;

    if (!title || !abstract || !authors || !field || !year) {
      return res.status(400).json({ message: 'Please fill in all required fields' });
    }

    // If a file was uploaded, build the URL; otherwise use the pasted link
    let resolvedFileUrl = fileUrl || '';
    if (req.file) {
      resolvedFileUrl = `/uploads/${req.file.filename}`;
    }

    const paper = await Paper.create({
      title,
      abstract,
      authors,
      field,
      year: Number(year),
      fileUrl: resolvedFileUrl,
      uploadedBy: req.user._id
    });

    // Populate uploader info before sending back
    await paper.populate('uploadedBy', 'name email');

    res.status(201).json({ message: 'Paper published successfully', paper });
  } catch (error) {
    console.error('Upload paper error:', error.message);
    res.status(500).json({ message: 'Failed to publish paper' });
  }
});

// ── PUT /api/papers/:id ──────────────────────────────────────
// Edit a paper (only the uploader or an admin can do this)
router.put('/:id', protect, async (req, res) => {
  try {
    const paper = await Paper.findById(req.params.id);
    if (!paper) return res.status(404).json({ message: 'Paper not found' });

    const isOwner = paper.uploadedBy.toString() === req.user._id.toString();
    const isAdmin = req.user.role === 'admin';
    if (!isOwner && !isAdmin) {
      return res.status(403).json({ message: 'Not authorised to edit this paper' });
    }

    const { title, abstract, authors, field, year, fileUrl } = req.body;
    if (title) paper.title = title;
    if (abstract) paper.abstract = abstract;
    if (authors) paper.authors = authors;
    if (field) paper.field = field;
    if (year) paper.year = Number(year);
    if (fileUrl !== undefined) paper.fileUrl = fileUrl;

    await paper.save();
    await paper.populate('uploadedBy', 'name email');

    res.json({ message: 'Paper updated', paper });
  } catch (error) {
    res.status(500).json({ message: 'Failed to update paper' });
  }
});

// ── DELETE /api/papers/:id ───────────────────────────────────
// Delete a paper (owner or admin only)
router.delete('/:id', protect, async (req, res) => {
  try {
    const paper = await Paper.findById(req.params.id);
    if (!paper) return res.status(404).json({ message: 'Paper not found' });

    const isOwner = paper.uploadedBy.toString() === req.user._id.toString();
    const isAdmin = req.user.role === 'admin';
    if (!isOwner && !isAdmin) {
      return res.status(403).json({ message: 'Not authorised to delete this paper' });
    }

    await paper.deleteOne();
    res.json({ message: 'Paper deleted successfully' });
  } catch (error) {
    res.status(500).json({ message: 'Failed to delete paper' });
  }
});

// ── POST /api/papers/:id/like ────────────────────────────────
// Toggle like on a paper (requires login)
router.post('/:id/like', protect, async (req, res) => {
  try {
    const paper = await Paper.findById(req.params.id);
    if (!paper) return res.status(404).json({ message: 'Paper not found' });

    const userId = req.user._id;
    const alreadyLiked = paper.likes.includes(userId);

    if (alreadyLiked) {
      paper.likes = paper.likes.filter((id) => id.toString() !== userId.toString());
    } else {
      paper.likes.push(userId);
    }

    await paper.save();
    res.json({ liked: !alreadyLiked, likesCount: paper.likes.length });
  } catch (error) {
    res.status(500).json({ message: 'Failed to toggle like' });
  }
});

// ── POST /api/papers/:id/bookmark ───────────────────────────
// Toggle bookmark on a paper (requires login)
router.post('/:id/bookmark', protect, async (req, res) => {
  try {
    const paper = await Paper.findById(req.params.id);
    if (!paper) return res.status(404).json({ message: 'Paper not found' });

    const userId = req.user._id;
    const alreadyBookmarked = paper.bookmarks.includes(userId);

    if (alreadyBookmarked) {
      paper.bookmarks = paper.bookmarks.filter((id) => id.toString() !== userId.toString());
    } else {
      paper.bookmarks.push(userId);
    }

    await paper.save();
    res.json({ bookmarked: !alreadyBookmarked });
  } catch (error) {
    res.status(500).json({ message: 'Failed to toggle bookmark' });
  }
});

// ── GET /api/papers/user/:userId ─────────────────────────────
// Get all papers uploaded by a specific user
router.get('/user/:userId', async (req, res) => {
  try {
    const papers = await Paper.find({ uploadedBy: req.params.userId })
      .populate('uploadedBy', 'name email')
      .sort({ createdAt: -1 });
    res.json({ papers });
  } catch (error) {
    res.status(500).json({ message: 'Failed to fetch user papers' });
  }
});

module.exports = router;
