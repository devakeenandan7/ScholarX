// models/Paper.js
const mongoose = require('mongoose');

const paperSchema = new mongoose.Schema(
  {
    title: {
      type: String,
      required: [true, 'Title is required'],
      trim: true,
      maxlength: [300, 'Title cannot exceed 300 characters']
    },
    abstract: {
      type: String,
      required: [true, 'Abstract is required'],
      trim: true,
      maxlength: [3000, 'Abstract cannot exceed 3000 characters']
    },
    // Stored as a comma-separated string for simplicity;
    // you could use [String] for an array instead
    authors: {
      type: String,
      required: [true, 'Authors are required'],
      trim: true
    },
    field: {
      type: String,
      required: [true, 'Field / discipline is required'],
      enum: ['cs', 'biology', 'physics', 'math', 'env', 'other']
    },
    year: {
      type: Number,
      required: [true, 'Publication year is required'],
      min: 1900,
      max: new Date().getFullYear() + 1
    },
    // URL to the PDF – either a link the user pasted or an /uploads path
    fileUrl: {
      type: String,
      default: ''
    },
    // Reference to the user who uploaded the paper
    uploadedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true
    },
    // Array of user IDs who liked this paper
    likes: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User'
      }
    ],
    // Array of user IDs who bookmarked this paper
    bookmarks: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User'
      }
    ]
  },
  {
    timestamps: true
  }
);

// ── Text index for search ────────────────────────────────────
// Allows MongoDB's $text operator to search title, abstract, and authors
paperSchema.index({ title: 'text', abstract: 'text', authors: 'text' });

module.exports = mongoose.model('Paper', paperSchema);
