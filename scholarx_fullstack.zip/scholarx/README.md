# ScholarX – Research Publication Platform

A clean, beginner-friendly full-stack research paper platform inspired by Google Scholar.

---

## Tech Stack

| Layer | Technology |
|---|---|
| Frontend | React 18, React Router v6, Tailwind CSS |
| Backend | Node.js, Express |
| Database | MongoDB (Mongoose ODM) |
| Auth | JWT + bcryptjs |
| File Upload | Multer (PDF → local `/uploads`) |

---

## Project Structure

```
scholarx/
├── package.json              ← root scripts (concurrently)
│
├── server/                   ← Express backend
│   ├── index.js              ← entry point, mounts routes
│   ├── .env.example          ← copy to .env and fill in values
│   ├── config/
│   │   └── db.js             ← MongoDB connection
│   ├── models/
│   │   ├── User.js           ← User schema (name, email, password, role)
│   │   └── Paper.js          ← Paper schema (title, abstract, authors …)
│   ├── middleware/
│   │   ├── auth.js           ← protect & adminOnly JWT middleware
│   │   └── upload.js         ← Multer PDF upload config
│   └── routes/
│       ├── auth.js           ← POST /signup  POST /login  GET /me
│       └── papers.js         ← full CRUD + /like + /bookmark
│
└── client/                   ← React frontend
    ├── public/
    │   └── index.html
    ├── tailwind.config.js
    └── src/
        ├── index.js
        ├── App.js            ← BrowserRouter + all routes
        ├── index.css         ← Tailwind directives
        ├── context/
        │   └── AuthContext.js  ← global auth state (user, login, logout)
        ├── utils/
        │   └── api.js          ← Axios instance, auto-attaches JWT
        ├── components/
        │   ├── Navbar.js
        │   ├── PaperCard.js    ← reusable card with like/bookmark
        │   └── Toast.js        ← global toast (call showToast('msg'))
        └── pages/
            ├── Home.js         ← search, filter, papers grid
            ├── Login.js
            ├── Signup.js
            ├── Upload.js       ← drag-and-drop PDF + form
            ├── PaperDetail.js  ← full paper view
            └── Profile.js      ← my papers + bookmarks
```

---

## Setup Instructions

### Prerequisites

- **Node.js** v18+ — https://nodejs.org
- **MongoDB** — either local install or free Atlas cluster:
  https://www.mongodb.com/atlas/database

---

### 1. Clone / download the project

```bash
git clone <your-repo-url> scholarx
cd scholarx
```

---

### 2. Configure the backend environment

```bash
cd server
cp .env.example .env
```

Open `server/.env` and set your values:

```env
MONGO_URI=mongodb://localhost:27017/scholarx   # or your Atlas URI
JWT_SECRET=change_this_to_a_long_random_string
PORT=5000
```

---

### 3. Install all dependencies

From the **project root**:

```bash
npm install          # installs concurrently
cd server && npm install
cd ../client && npm install
```

---

### 4. Run the app (development)

Open **two terminals**:

**Terminal 1 – backend**
```bash
cd server
npm run dev       # nodemon auto-restarts on file changes
```

**Terminal 2 – frontend**
```bash
cd client
npm start         # opens http://localhost:3000
```

Or from the project root (both at once):
```bash
npm run dev
```

The React app proxies `/api` requests to `http://localhost:5000` automatically.

---

## API Reference

### Auth  (`/api/auth`)

| Method | Endpoint | Auth | Description |
|---|---|---|---|
| POST | `/api/auth/signup` | — | Create account |
| POST | `/api/auth/login` | — | Login, get JWT |
| GET | `/api/auth/me` | ✅ JWT | Get current user |

### Papers  (`/api/papers`)

| Method | Endpoint | Auth | Description |
|---|---|---|---|
| GET | `/api/papers` | — | List all; supports `?q=` and `?field=` |
| GET | `/api/papers/:id` | — | Single paper detail |
| POST | `/api/papers` | ✅ | Upload paper (multipart/form-data) |
| PUT | `/api/papers/:id` | ✅ owner/admin | Edit paper |
| DELETE | `/api/papers/:id` | ✅ owner/admin | Delete paper |
| POST | `/api/papers/:id/like` | ✅ | Toggle like |
| POST | `/api/papers/:id/bookmark` | ✅ | Toggle bookmark |
| GET | `/api/papers/user/:userId` | — | Papers by user |

---

## Key Design Decisions

**Why JWT in localStorage?**
Simple to implement for a beginner project. In production, consider httpOnly cookies.

**Why store authors as a string?**
Keeps the schema simple. Split by comma on the client. You can change it to `[String]` later.

**Why multer for uploads?**
Zero dependencies beyond multer itself. Files land in `/server/uploads/` and are served as static assets. For production, swap to S3/Cloudinary.

**Why `select: false` on password?**
Mongoose never returns the password field in queries unless you explicitly add `.select('+password')`. This prevents accidental leaks.

---

## Production Notes

1. Set `NODE_ENV=production` and use a proper `JWT_SECRET` (32+ random chars)
2. Serve the React build from Express: `app.use(express.static('../client/build'))`
3. Store uploads on S3/Cloudinary instead of the local filesystem
4. Add rate limiting (`express-rate-limit`) on auth routes
5. Use HTTPS (Let's Encrypt / your host's SSL)
