// components/PaperCard.js
// Renders a single paper in a card layout.
// Used on the Home page feed and the Profile page.

import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import api from '../utils/api';
import { showToast } from './Toast';

// Field labels and badge colours
const FIELDS = {
  cs: { label: 'Computer Science', style: 'bg-blue-100 text-blue-800' },
  biology: { label: 'Biology', style: 'bg-green-100 text-green-800' },
  physics: { label: 'Physics', style: 'bg-yellow-100 text-yellow-800' },
  math: { label: 'Mathematics', style: 'bg-purple-100 text-purple-800' },
  env: { label: 'Environmental', style: 'bg-emerald-100 text-emerald-800' },
  other: { label: 'Other', style: 'bg-gray-100 text-gray-700' }
};

export default function PaperCard({ paper, onUpdate }) {
  const navigate = useNavigate();
  const { user } = useAuth();
  const field = FIELDS[paper.field] || FIELDS.other;

  const authorsList = paper.authors.split(',').slice(0, 2).join(',')
    + (paper.authors.split(',').length > 2 ? ' et al.' : '');

  const likesCount = paper.likes?.length || 0;
  const isLiked = user && paper.likes?.includes(user.id);
  const isBookmarked = user && paper.bookmarks?.includes(user.id);

  // Prevent the card click from firing when clicking action buttons
  const stopProp = (fn) => (e) => { e.stopPropagation(); fn(); };

  const handleLike = async () => {
    if (!user) { navigate('/login'); return; }
    try {
      await api.post(`/papers/${paper._id}/like`);
      onUpdate && onUpdate(); // Tell parent to re-fetch
    } catch {
      showToast('Failed to update like');
    }
  };

  const handleBookmark = async () => {
    if (!user) { navigate('/login'); return; }
    try {
      await api.post(`/papers/${paper._id}/bookmark`);
      showToast(isBookmarked ? 'Bookmark removed' : 'Paper bookmarked');
      onUpdate && onUpdate();
    } catch {
      showToast('Failed to update bookmark');
    }
  };

  return (
    <div
      onClick={() => navigate(`/papers/${paper._id}`)}
      className="bg-white border border-gray-200 rounded-xl p-5 cursor-pointer hover:border-accent hover:shadow-lg hover:-translate-y-0.5 transition-all duration-200 flex flex-col"
    >
      {/* Field badge */}
      <span className={`inline-block text-xs font-medium px-2.5 py-0.5 rounded-full mb-3 ${field.style}`}>
        {field.label}
      </span>

      {/* Title */}
      <h3 className="font-medium text-base leading-snug mb-2" style={{ fontFamily: 'Fraunces, serif' }}>
        {paper.title}
      </h3>

      {/* Authors */}
      <p className="text-xs text-accent font-medium mb-2">{authorsList}</p>

      {/* Abstract preview */}
      <p className="text-xs text-gray-500 leading-relaxed line-clamp-3 mb-4 flex-1">
        {paper.abstract}
      </p>

      {/* Footer */}
      <div className="flex items-center justify-between border-t border-gray-100 pt-3 mt-auto text-xs text-gray-400">
        <span>{paper.year} · {paper.uploadedBy?.name?.split(' ')[0] || 'Unknown'}</span>

        <div className="flex gap-1.5" onClick={(e) => e.stopPropagation()}>
          {/* Like button */}
          <button
            onClick={stopProp(handleLike)}
            className={`px-2 py-1 rounded-md border text-xs transition-colors ${
              isLiked
                ? 'border-red-200 bg-red-50 text-red-500'
                : 'border-gray-200 hover:bg-gray-50 text-gray-400'
            }`}
          >
            {isLiked ? '♥' : '♡'} {likesCount}
          </button>

          {/* Bookmark button */}
          <button
            onClick={stopProp(handleBookmark)}
            className={`px-2 py-1 rounded-md border text-xs transition-colors ${
              isBookmarked
                ? 'border-yellow-200 bg-yellow-50 text-yellow-600'
                : 'border-gray-200 hover:bg-gray-50 text-gray-400'
            }`}
          >
            🔖
          </button>
        </div>
      </div>
    </div>
  );
}
