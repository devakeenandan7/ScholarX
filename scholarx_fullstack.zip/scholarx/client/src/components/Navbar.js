// components/Navbar.js
import React from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

export default function Navbar() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const { pathname } = useLocation();

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  // Initials avatar
  const initials = user
    ? user.name.split(' ').map((n) => n[0]).join('').slice(0, 2).toUpperCase()
    : '';

  const navLink = (to, label) => (
    <Link
      to={to}
      className={`px-3 py-1.5 rounded-md text-sm transition-colors ${
        pathname === to
          ? 'bg-white/10 text-white'
          : 'text-white/60 hover:text-white hover:bg-white/10'
      }`}
    >
      {label}
    </Link>
  );

  return (
    <nav className="bg-navy sticky top-0 z-50 shadow-lg">
      <div className="max-w-6xl mx-auto px-4 h-14 flex items-center gap-4">
        {/* Logo */}
        <Link to="/" className="flex items-center gap-2 mr-2">
          <span className="w-2 h-2 rounded-full bg-teal inline-block" />
          <span
            className="text-white text-xl font-medium"
            style={{ fontFamily: 'Fraunces, serif' }}
          >
            ScholarX
          </span>
        </Link>

        {/* Nav links */}
        <div className="flex gap-1">
          {navLink('/', 'Home')}
          {navLink('/upload', 'Upload Paper')}
          {user && navLink('/profile', 'Profile')}
        </div>

        <div className="ml-auto flex items-center gap-2">
          {user ? (
            <>
              {/* Avatar chip */}
              <Link
                to="/profile"
                className="flex items-center gap-2 text-white/80 text-sm hover:text-white"
              >
                <div className="w-8 h-8 rounded-full bg-gradient-to-br from-teal to-accent flex items-center justify-center text-white text-xs font-semibold">
                  {initials}
                </div>
                <span className="hidden sm:inline">{user.name.split(' ')[0]}</span>
              </Link>
              <button
                onClick={handleLogout}
                className="px-3 py-1.5 rounded-md border border-white/30 text-white text-sm hover:bg-white/10 transition-colors"
              >
                Logout
              </button>
            </>
          ) : (
            <>
              <Link
                to="/login"
                className="px-3 py-1.5 rounded-md border border-white/30 text-white text-sm hover:bg-white/10 transition-colors"
              >
                Sign in
              </Link>
              <Link
                to="/signup"
                className="px-3 py-1.5 rounded-md bg-accent text-white text-sm hover:bg-blue-600 transition-colors"
              >
                Sign up
              </Link>
            </>
          )}
        </div>
      </div>
    </nav>
  );
}
