// components/Toast.js
// A lightweight global toast notification.
// Usage anywhere: import { showToast } from '../components/Toast';
//                 showToast('Paper uploaded!');

import React, { useState, useEffect } from 'react';

// Module-level queue so showToast() can be called from outside React
let _setMessage = null;

export const showToast = (msg) => {
  if (_setMessage) _setMessage(msg);
};

export default function Toast() {
  const [message, setMessage] = useState('');
  const [visible, setVisible] = useState(false);

  // Register the setter so showToast() can reach it
  useEffect(() => {
    _setMessage = (msg) => {
      setMessage(msg);
      setVisible(true);
    };
    return () => { _setMessage = null; };
  }, []);

  // Auto-hide after 2.5 s
  useEffect(() => {
    if (!visible) return;
    const t = setTimeout(() => setVisible(false), 2500);
    return () => clearTimeout(t);
  }, [visible]);

  if (!visible) return null;

  return (
    <div className="fixed bottom-5 right-5 z-[999] bg-navy text-white text-sm px-4 py-2.5 rounded-lg shadow-xl animate-fade-in">
      {message}
    </div>
  );
}
