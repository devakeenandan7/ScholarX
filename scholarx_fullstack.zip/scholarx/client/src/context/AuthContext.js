// context/AuthContext.js
// Provides the currently logged-in user and auth helpers to all components

import React, { createContext, useContext, useState, useEffect } from 'react';
import api from '../utils/api';

const AuthContext = createContext(null);

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true); // Checking localStorage on startup

  // On first load, restore user from localStorage (token persists across refreshes)
  useEffect(() => {
    const storedUser = localStorage.getItem('scholarx_user');
    const token = localStorage.getItem('scholarx_token');
    if (storedUser && token) {
      setUser(JSON.parse(storedUser));
    }
    setLoading(false);
  }, []);

  // Call this after a successful login or signup
  const login = (userData, token) => {
    localStorage.setItem('scholarx_token', token);
    localStorage.setItem('scholarx_user', JSON.stringify(userData));
    setUser(userData);
  };

  const logout = () => {
    localStorage.removeItem('scholarx_token');
    localStorage.removeItem('scholarx_user');
    setUser(null);
  };

  return (
    <AuthContext.Provider value={{ user, login, logout, loading }}>
      {children}
    </AuthContext.Provider>
  );
};

// Custom hook – components call:  const { user, login, logout } = useAuth();
export const useAuth = () => useContext(AuthContext);
