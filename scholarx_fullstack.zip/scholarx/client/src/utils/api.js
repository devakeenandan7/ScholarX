// utils/api.js
// Pre-configured Axios instance that automatically attaches the JWT
// to every request that needs authentication.

import axios from 'axios';

const api = axios.create({
  baseURL: '/api', // Proxied to http://localhost:5000/api by CRA proxy setting
  headers: { 'Content-Type': 'application/json' }
});

// Request interceptor – attach token if present
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('scholarx_token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

// Response interceptor – clear auth on 401 (token expired / invalid)
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      localStorage.removeItem('scholarx_token');
      localStorage.removeItem('scholarx_user');
    }
    return Promise.reject(error);
  }
);

export default api;
