// pages/Upload.js
import React, { useState, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import api from '../utils/api';
import { showToast } from '../components/Toast';

export default function Upload() {
  const navigate = useNavigate();
  const fileRef = useRef(null);

  const [form, setForm] = useState({
    title: '', abstract: '', authors: '', field: 'cs', year: new Date().getFullYear(), fileUrl: ''
  });
  const [file, setFile] = useState(null);
  const [dragOver, setDragOver] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
    setError('');
  };

  const handleFile = (f) => {
    if (f && f.type === 'application/pdf') {
      setFile(f);
    } else {
      showToast('Please select a PDF file');
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!form.title || !form.abstract || !form.authors || !form.year) {
      setError('Please fill in all required fields');
      return;
    }
    if (form.abstract.length < 50) {
      setError('Abstract should be at least 50 characters');
      return;
    }

    setLoading(true);
    try {
      // Use FormData so we can send both text fields and the PDF file
      const formData = new FormData();
      Object.entries(form).forEach(([k, v]) => formData.append(k, v));
      if (file) formData.append('pdf', file);

      await api.post('/papers', formData, {
        headers: { 'Content-Type': 'multipart/form-data' }
      });

      showToast('Paper published successfully!');
      navigate('/');
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to publish paper');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto px-4 py-10">
      <h2 className="text-3xl mb-1" style={{ fontFamily: 'Fraunces, serif', fontWeight: 500 }}>
        Upload Research Paper
      </h2>
      <p className="text-gray-400 text-sm mb-8">Share your research with the ScholarX community.</p>

      <div className="bg-white border border-gray-200 rounded-xl p-7">
        {error && (
          <div className="mb-5 p-3 bg-red-50 border border-red-200 text-red-600 text-sm rounded-lg">{error}</div>
        )}

        <form onSubmit={handleSubmit} className="space-y-5">
          {/* Title */}
          <div>
            <label className="block text-xs font-medium text-gray-500 uppercase tracking-wide mb-1.5">Paper title *</label>
            <input name="title" value={form.title} onChange={handleChange}
              placeholder="e.g., Deep Learning for Natural Language Processing"
              className="w-full px-3.5 py-2.5 border border-gray-200 rounded-lg text-sm bg-gray-50 focus:outline-none focus:border-accent focus:bg-white transition-colors" />
          </div>

          {/* Authors */}
          <div>
            <label className="block text-xs font-medium text-gray-500 uppercase tracking-wide mb-1.5">Authors * (comma separated)</label>
            <input name="authors" value={form.authors} onChange={handleChange}
              placeholder="Jane Smith, John Doe, Alice Brown"
              className="w-full px-3.5 py-2.5 border border-gray-200 rounded-lg text-sm bg-gray-50 focus:outline-none focus:border-accent focus:bg-white transition-colors" />
          </div>

          {/* Abstract */}
          <div>
            <label className="block text-xs font-medium text-gray-500 uppercase tracking-wide mb-1.5">Abstract *</label>
            <textarea name="abstract" value={form.abstract} onChange={handleChange} rows={5}
              placeholder="Provide a concise summary of your research (150–300 words recommended)..."
              className="w-full px-3.5 py-2.5 border border-gray-200 rounded-lg text-sm bg-gray-50 focus:outline-none focus:border-accent focus:bg-white transition-colors resize-y" />
          </div>

          {/* Field + Year */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-gray-500 uppercase tracking-wide mb-1.5">Field *</label>
              <select name="field" value={form.field} onChange={handleChange}
                className="w-full px-3.5 py-2.5 border border-gray-200 rounded-lg text-sm bg-gray-50 focus:outline-none focus:border-accent focus:bg-white transition-colors">
                <option value="cs">Computer Science</option>
                <option value="biology">Biology</option>
                <option value="physics">Physics</option>
                <option value="math">Mathematics</option>
                <option value="env">Environmental Science</option>
                <option value="other">Other</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-500 uppercase tracking-wide mb-1.5">Year *</label>
              <input name="year" type="number" value={form.year} onChange={handleChange}
                min="1900" max={new Date().getFullYear() + 1}
                className="w-full px-3.5 py-2.5 border border-gray-200 rounded-lg text-sm bg-gray-50 focus:outline-none focus:border-accent focus:bg-white transition-colors" />
            </div>
          </div>

          {/* PDF drag-and-drop */}
          <div>
            <label className="block text-xs font-medium text-gray-500 uppercase tracking-wide mb-1.5">PDF File</label>
            <div
              onClick={() => fileRef.current.click()}
              onDragOver={(e) => { e.preventDefault(); setDragOver(true); }}
              onDragLeave={() => setDragOver(false)}
              onDrop={(e) => { e.preventDefault(); setDragOver(false); handleFile(e.dataTransfer.files[0]); }}
              className={`border-2 border-dashed rounded-xl p-8 text-center cursor-pointer transition-colors ${
                dragOver ? 'border-accent bg-blue-50' : 'border-gray-200 hover:border-accent hover:bg-gray-50'
              }`}
            >
              <div className="text-3xl mb-2">📄</div>
              <p className="text-sm text-gray-500">
                {file ? (
                  <span className="text-accent font-medium">{file.name}</span>
                ) : (
                  <><span className="text-accent font-medium">Click to upload</span> or drag & drop</>
                )}
              </p>
              <p className="text-xs text-gray-400 mt-1">PDF only · max 20 MB</p>
              <input ref={fileRef} type="file" accept=".pdf" className="hidden"
                onChange={(e) => handleFile(e.target.files[0])} />
            </div>
          </div>

          {/* OR external URL */}
          <div>
            <label className="block text-xs font-medium text-gray-500 uppercase tracking-wide mb-1.5">Or paste PDF URL</label>
            <input name="fileUrl" value={form.fileUrl} onChange={handleChange}
              placeholder="https://arxiv.org/pdf/..."
              className="w-full px-3.5 py-2.5 border border-gray-200 rounded-lg text-sm bg-gray-50 focus:outline-none focus:border-accent focus:bg-white transition-colors" />
          </div>

          <button type="submit" disabled={loading}
            className="w-full py-3 bg-accent text-white rounded-xl text-sm font-medium hover:bg-blue-600 transition-colors disabled:opacity-60">
            {loading ? 'Publishing...' : 'Publish Paper →'}
          </button>
        </form>
      </div>
    </div>
  );
}
