// pages/PaperDetail.js
import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import api from '../utils/api';
import { showToast } from '../components/Toast';

const FIELDS = {
  cs: 'Computer Science', biology: 'Biology', physics: 'Physics',
  math: 'Mathematics', env: 'Environmental Science', other: 'Other'
};

export default function PaperDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const [paper, setPaper] = useState(null);
  const [loading, setLoading] = useState(true);

  const fetchPaper = async () => {
    try {
      const { data } = await api.get(`/papers/${id}`);
      setPaper(data.paper);
    } catch {
      navigate('/');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchPaper(); }, [id]);

  const handleLike = async () => {
    if (!user) { navigate('/login'); return; }
    await api.post(`/papers/${id}/like`);
    fetchPaper();
  };

  const handleBookmark = async () => {
    if (!user) { navigate('/login'); return; }
    const isBk = paper.bookmarks?.includes(user.id);
    await api.post(`/papers/${id}/bookmark`);
    showToast(isBk ? 'Bookmark removed' : 'Paper bookmarked');
    fetchPaper();
  };

  const handleDelete = async () => {
    if (!window.confirm('Delete this paper?')) return;
    try {
      await api.delete(`/papers/${id}`);
      showToast('Paper deleted');
      navigate('/');
    } catch {
      showToast('Failed to delete paper');
    }
  };

  if (loading) return (
    <div className="max-w-3xl mx-auto px-4 py-12 animate-pulse">
      <div className="h-5 bg-gray-200 rounded w-1/4 mb-6" />
      <div className="h-8 bg-gray-200 rounded w-3/4 mb-3" />
      <div className="h-4 bg-gray-200 rounded w-1/2 mb-6" />
      <div className="space-y-2">{[...Array(5)].map((_, i) => <div key={i} className="h-3 bg-gray-100 rounded" />)}</div>
    </div>
  );

  if (!paper) return null;

  const isLiked = user && paper.likes?.includes(user.id);
  const isBookmarked = user && paper.bookmarks?.includes(user.id);
  const isOwner = user && paper.uploadedBy?._id === user.id;
  const isAdmin = user?.role === 'admin';

  return (
    <div className="max-w-3xl mx-auto px-4 py-10">
      {/* Back */}
      <button onClick={() => navigate(-1)} className="text-sm text-gray-400 hover:text-accent mb-6 flex items-center gap-1">
        ← Back
      </button>

      {/* Field badge */}
      <span className="inline-block text-xs font-medium px-2.5 py-0.5 rounded-full bg-blue-100 text-blue-800 mb-4">
        {FIELDS[paper.field] || 'Other'}
      </span>

      {/* Title */}
      <h1 className="text-3xl leading-snug mb-3" style={{ fontFamily: 'Fraunces, serif', fontWeight: 500 }}>
        {paper.title}
      </h1>

      {/* Authors */}
      <p className="text-accent font-medium text-sm mb-6">By {paper.authors}</p>

      {/* Action buttons */}
      <div className="flex flex-wrap gap-2 mb-8">
        {paper.fileUrl && (
          <a href={paper.fileUrl} target="_blank" rel="noreferrer"
            className="px-4 py-2 bg-teal text-white rounded-lg text-sm font-medium hover:opacity-90 transition-opacity">
            View PDF →
          </a>
        )}
        <button onClick={handleLike}
          className={`px-4 py-2 rounded-lg text-sm border transition-colors ${
            isLiked ? 'bg-red-50 border-red-200 text-red-500' : 'bg-white border-gray-200 text-gray-600 hover:bg-gray-50'
          }`}>
          {isLiked ? '♥' : '♡'} Like ({paper.likes?.length || 0})
        </button>
        <button onClick={handleBookmark}
          className={`px-4 py-2 rounded-lg text-sm border transition-colors ${
            isBookmarked ? 'bg-yellow-50 border-yellow-200 text-yellow-600' : 'bg-white border-gray-200 text-gray-600 hover:bg-gray-50'
          }`}>
          🔖 {isBookmarked ? 'Bookmarked' : 'Bookmark'}
        </button>
        {(isOwner || isAdmin) && (
          <button onClick={handleDelete}
            className="px-4 py-2 bg-red-50 border border-red-200 text-red-600 rounded-lg text-sm hover:bg-red-100 transition-colors">
            Delete
          </button>
        )}
      </div>

      {/* Meta grid */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-8">
        {[
          { label: 'Year', value: paper.year },
          { label: 'Field', value: FIELDS[paper.field] },
          { label: 'Uploaded by', value: paper.uploadedBy?.name || 'Unknown' },
          { label: 'Likes', value: paper.likes?.length || 0 }
        ].map(({ label, value }) => (
          <div key={label} className="bg-gray-50 rounded-lg p-3">
            <div className="text-xs text-gray-400 uppercase tracking-wide mb-1">{label}</div>
            <div className="text-sm font-medium text-gray-800">{value}</div>
          </div>
        ))}
      </div>

      {/* Abstract */}
      <div className="bg-white border border-gray-200 rounded-xl p-6">
        <h2 className="text-lg font-medium mb-3" style={{ fontFamily: 'Fraunces, serif' }}>Abstract</h2>
        <p className="text-gray-600 text-sm leading-relaxed">{paper.abstract}</p>
      </div>
    </div>
  );
}
