// pages/Profile.js
import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import api from '../utils/api';
import PaperCard from '../components/PaperCard';

export default function Profile() {
  const { user } = useAuth();
  const [myPapers, setMyPapers] = useState([]);
  const [bookmarked, setBookmarked] = useState([]);
  const [loading, setLoading] = useState(true);

  const fetchData = async () => {
    try {
      // Fetch papers this user uploaded
      const { data: myData } = await api.get(`/papers/user/${user.id}`);
      setMyPapers(myData.papers);

      // Fetch all papers and filter bookmarked ones
      const { data: allData } = await api.get('/papers?limit=100');
      const bkd = allData.papers.filter((p) => p.bookmarks?.includes(user.id));
      setBookmarked(bkd);
    } catch (err) {
      console.error('Profile fetch error', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { if (user) fetchData(); }, [user]);

  const initials = user?.name.split(' ').map((n) => n[0]).join('').slice(0, 2).toUpperCase();
  const totalLikes = myPapers.reduce((sum, p) => sum + (p.likes?.length || 0), 0);

  return (
    <div>
      {/* Header */}
      <div className="text-center py-12 px-4" style={{ background: 'linear-gradient(135deg,#0a0f2e,#1a3a8f)' }}>
        <div className="w-18 h-18 mx-auto mb-4 rounded-full flex items-center justify-center text-white text-2xl font-semibold"
          style={{ width: 72, height: 72, background: 'linear-gradient(135deg,#0dcfb4,#3d7eff)', fontFamily: 'Fraunces, serif' }}>
          {initials}
        </div>
        <h2 className="text-white text-2xl mb-1" style={{ fontFamily: 'Fraunces, serif', fontWeight: 500 }}>{user?.name}</h2>
        <p className="text-white/50 text-sm mb-4">{user?.email}</p>
        <div className="flex justify-center gap-2 flex-wrap">
          <span className="px-3 py-1 rounded-full bg-white/10 text-white/80 text-xs">
            {user?.role === 'admin' ? 'Administrator' : 'Researcher'}
          </span>
        </div>
      </div>

      <div className="max-w-5xl mx-auto px-4 py-8">
        {/* Stats */}
        <div className="grid grid-cols-3 gap-3 mb-10">
          {[
            { num: myPapers.length, label: 'Papers uploaded' },
            { num: totalLikes, label: 'Likes received' },
            { num: bookmarked.length, label: 'Bookmarks' }
          ].map(({ num, label }) => (
            <div key={label} className="bg-white border border-gray-200 rounded-xl p-4 text-center">
              <div className="text-3xl mb-1" style={{ fontFamily: 'Fraunces, serif', fontWeight: 300 }}>{num}</div>
              <div className="text-xs text-gray-400 uppercase tracking-wide">{label}</div>
            </div>
          ))}
        </div>

        {/* My Papers */}
        <h3 className="text-xl font-medium mb-4" style={{ fontFamily: 'Fraunces, serif' }}>My Published Papers</h3>
        {loading ? (
          <p className="text-gray-400 text-sm mb-8">Loading...</p>
        ) : myPapers.length === 0 ? (
          <div className="text-center py-10 text-gray-400 mb-8">
            <div className="text-3xl mb-2">📋</div>
            <p>No papers uploaded yet.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 mb-10">
            {myPapers.map((p) => <PaperCard key={p._id} paper={p} onUpdate={fetchData} />)}
          </div>
        )}

        {/* Bookmarked Papers */}
        <h3 className="text-xl font-medium mb-4" style={{ fontFamily: 'Fraunces, serif' }}>Bookmarked Papers</h3>
        {bookmarked.length === 0 ? (
          <div className="text-center py-10 text-gray-400">
            <div className="text-3xl mb-2">🔖</div>
            <p>No bookmarked papers yet.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {bookmarked.map((p) => <PaperCard key={p._id} paper={p} onUpdate={fetchData} />)}
          </div>
        )}
      </div>
    </div>
  );
}
