// pages/Login.js
import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import api from '../utils/api';
import { showToast } from '../components/Toast';

export default function Login() {
  const navigate = useNavigate();
  const { login } = useAuth();
  const [form, setForm] = useState({ email: '', password: '' });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
    setError('');
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!form.email || !form.password) {
      setError('Please fill in all fields');
      return;
    }
    setLoading(true);
    try {
      const { data } = await api.post('/auth/login', form);
      login(data.user, data.token);
      showToast(`Welcome back, ${data.user.name.split(' ')[0]}!`);
      navigate('/');
    } catch (err) {
      setError(err.response?.data?.message || 'Login failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex min-h-[calc(100vh-56px)]">
      {/* Left decorative panel */}
      <div
        className="hidden md:flex flex-1 items-center justify-center p-12"
        style={{ background: 'linear-gradient(160deg,#0a0f2e,#1a3a8f)' }}
      >
        <div className="text-center max-w-xs">
          <h2 className="text-white text-3xl mb-3 leading-snug" style={{ fontFamily: 'Fraunces, serif', fontWeight: 300 }}>
            Welcome back to ScholarX
          </h2>
          <p className="text-white/50 text-sm leading-relaxed">
            Continue your research journey. Access thousands of papers and share your discoveries.
          </p>
        </div>
      </div>

      {/* Right form panel */}
      <div className="flex-1 flex items-center justify-center bg-white p-8">
        <div className="w-full max-w-sm">
          <h3 className="text-2xl mb-1" style={{ fontFamily: 'Fraunces, serif', fontWeight: 500 }}>Sign in</h3>
          <p className="text-gray-400 text-sm mb-7">Access your ScholarX account</p>

          {error && (
            <div className="mb-4 p-3 bg-red-50 border border-red-200 text-red-600 text-sm rounded-lg">
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-medium text-gray-500 uppercase tracking-wide mb-1.5">Email</label>
              <input
                name="email" type="email" value={form.email} onChange={handleChange}
                placeholder="you@university.edu"
                className="w-full px-3.5 py-2.5 border border-gray-200 rounded-lg text-sm bg-gray-50 focus:outline-none focus:border-accent focus:bg-white transition-colors"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-500 uppercase tracking-wide mb-1.5">Password</label>
              <input
                name="password" type="password" value={form.password} onChange={handleChange}
                placeholder="Your password"
                className="w-full px-3.5 py-2.5 border border-gray-200 rounded-lg text-sm bg-gray-50 focus:outline-none focus:border-accent focus:bg-white transition-colors"
              />
            </div>
            <button
              type="submit" disabled={loading}
              className="w-full py-2.5 bg-accent text-white rounded-lg text-sm font-medium hover:bg-blue-600 transition-colors disabled:opacity-60"
            >
              {loading ? 'Signing in...' : 'Sign in →'}
            </button>
          </form>

          <p className="text-center text-sm text-gray-400 mt-5">
            Don't have an account?{' '}
            <Link to="/signup" className="text-accent hover:underline">Sign up here</Link>
          </p>
        </div>
      </div>
    </div>
  );
}
