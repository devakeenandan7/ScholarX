// pages/Home.js
import React, { useState, useEffect, useCallback } from 'react';
import api from '../utils/api';
import PaperCard from '../components/PaperCard';

const FIELDS = [
  { value: 'all', label: 'All Fields' },
  { value: 'cs', label: 'Computer Science' },
  { value: 'biology', label: 'Biology' },
  { value: 'physics', label: 'Physics' },
  { value: 'math', label: 'Mathematics' },
  { value: 'env', label: 'Environmental' }
];

export default function Home() {
  const [papers, setPapers] = useState([]);
  const [total, setTotal] = useState(0);
  const [loading, setLoading] = useState(true);
  const [query, setQuery] = useState('');
  const [field, setField] = useState('all');
  const [inputValue, setInputValue] = useState('');

  const fetchPapers = useCallback(async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      if (query) params.append('q', query);
      if (field !== 'all') params.append('field', field);
      const { data } = await api.get(`/papers?${params}`);
      setPapers(data.papers);
      setTotal(data.total);
    } catch (err) {
      console.error('Failed to fetch papers', err);
    } finally {
      setLoading(false);
    }
  }, [query, field]);

  useEffect(() => { fetchPapers(); }, [fetchPapers]);

  const handleSearch = (e) => {
    e.preventDefault();
    setQuery(inputValue.trim());
  };

  return (
    <div>
      {/* ── Hero ────────────────────────────────────────────── */}
      <div className="bg-navy" style={{ background: 'linear-gradient(135deg,#0a0f2e 0%,#0f1a45 60%,#12204f 100%)' }}>
        <div className="max-w-4xl mx-auto px-4 py-14 text-center">
          <div className="inline-block px-3 py-1 rounded-full border border-accent/40 bg-accent/10 text-accent/80 text-xs tracking-widest uppercase mb-5">
            Open Research Platform
          </div>
          <h1 className="text-white text-4xl md:text-5xl mb-4 leading-tight" style={{ fontFamily: 'Fraunces, serif', fontWeight: 400 }}>
            Discover &amp; Share<br /><em className="text-teal not-italic">Research Papers</em>
          </h1>
          <p className="text-white/60 text-base mb-8 max-w-md mx-auto leading-relaxed">
            A simplified academic publishing platform to upload, browse, and search research publications across all disciplines.
          </p>

          {/* Search bar */}
          <form onSubmit={handleSearch} className="flex max-w-xl mx-auto">
            <input
              type="text"
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              placeholder="Search by title, author, or keyword..."
              className="flex-1 px-4 py-3 rounded-l-xl bg-white/10 border border-white/20 text-white placeholder-white/40 focus:outline-none focus:border-accent/60 text-sm"
            />
            <button
              type="submit"
              className="px-5 py-3 bg-accent text-white rounded-r-xl text-sm font-medium hover:bg-blue-600 transition-colors"
            >
              Search
            </button>
          </form>

          {/* Stats */}
          <div className="flex justify-center gap-10 mt-10">
            {[
              { num: total, label: 'Papers' },
              { num: 12, label: 'Authors' },
              { num: 5, label: 'Fields' }
            ].map(({ num, label }) => (
              <div key={label} className="text-center">
                <div className="text-white text-2xl" style={{ fontFamily: 'Fraunces, serif', fontWeight: 300 }}>{num}</div>
                <div className="text-white/40 text-xs uppercase tracking-widest">{label}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* ── Papers feed ─────────────────────────────────────── */}
      <div className="max-w-6xl mx-auto px-4 py-8">
        {/* Filters */}
        <div className="flex flex-wrap items-center justify-between gap-4 mb-6">
          <h2 className="text-xl font-medium" style={{ fontFamily: 'Fraunces, serif' }}>Research Papers</h2>
          <div className="flex flex-wrap gap-2">
            {FIELDS.map(({ value, label }) => (
              <button
                key={value}
                onClick={() => setField(value)}
                className={`px-3 py-1.5 rounded-full text-xs border transition-colors ${
                  field === value
                    ? 'bg-navy border-navy text-white'
                    : 'bg-white border-gray-200 text-gray-500 hover:border-gray-400'
                }`}
              >
                {label}
              </button>
            ))}
          </div>
        </div>

        {/* Results info */}
        {query && (
          <p className="text-sm text-gray-400 mb-4">
            {papers.length} result{papers.length !== 1 ? 's' : ''} for "{query}"
            <button onClick={() => { setQuery(''); setInputValue(''); }} className="ml-2 text-accent hover:underline">
              Clear
            </button>
          </p>
        )}

        {/* Grid */}
        {loading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {[...Array(6)].map((_, i) => (
              <div key={i} className="bg-white border border-gray-200 rounded-xl p-5 animate-pulse">
                <div className="h-3 bg-gray-200 rounded w-1/3 mb-4" />
                <div className="h-4 bg-gray-200 rounded w-full mb-2" />
                <div className="h-4 bg-gray-200 rounded w-3/4 mb-4" />
                <div className="h-3 bg-gray-100 rounded w-full mb-1" />
                <div className="h-3 bg-gray-100 rounded w-5/6" />
              </div>
            ))}
          </div>
        ) : papers.length === 0 ? (
          <div className="text-center py-20 text-gray-400">
            <div className="text-4xl mb-3">📋</div>
            <p className="text-lg">No papers found.</p>
            {query && <p className="text-sm mt-1">Try a different search term.</p>}
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {papers.map((paper) => (
              <PaperCard key={paper._id} paper={paper} onUpdate={fetchPapers} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
