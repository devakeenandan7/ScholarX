/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ['./src/**/*.{js,jsx,ts,tsx}'],
  theme: {
    extend: {
      fontFamily: {
        sans: ['DM Sans', 'sans-serif'],
        serif: ['Fraunces', 'serif']
      },
      colors: {
        navy: {
          DEFAULT: '#0a0f2e',
          light: '#0f1a45'
        },
        accent: {
          DEFAULT: '#3d7eff',
          light: '#6fa3ff'
        },
        teal: '#0dcfb4'
      }
    }
  },
  plugins: []
};
